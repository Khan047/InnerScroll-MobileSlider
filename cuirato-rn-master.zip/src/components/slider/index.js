import React from 'react'

const ChefSlider = () => {
    return (
        <div>
            fsdfsd
        </div>
    )
}

export default ChefSlider
